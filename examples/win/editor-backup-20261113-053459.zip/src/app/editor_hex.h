/*
 ** editor_hex.h - 3 functions.
 ** editor_hex_draw - Display the byte grid and optional preview action.
 ** editor_hex_mouse - Select bytes, scroll, or activate the full editor.
 ** editor_hex_key - Navigate the grid and overwrite individual nibbles.
 ** See also: hex_view.c, hex_input.c.
 */
#pragma once
#include "editor_view.h"

void editor_hex_draw(editor_view* view, editor_document* doc, ui_renderer* renderer, ui_window* window,
                     u32 width, u32 bottom, const editor_settings* settings);
void editor_hex_mouse(editor_view* view, editor_document* doc, ui_input input);
void editor_hex_key(editor_view* view, editor_document* doc, ui_input input);
