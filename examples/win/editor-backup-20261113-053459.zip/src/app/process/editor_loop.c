/*
 ** editor_loop.c - 1 function.
 ** editor_run - Run the editor event loop and release its session resources.
 ** See also: editor_session.h, main_internal.h.
 */
#include "main_internal.h"

i32 editor_run(ui_window* window, ui_renderer* renderer, editor_document* document,
                       editor_settings* settings) {
    editor_view view = {.caret_visible_since_ms = ui_time_ms()};
    if (!editor_tabs_open(&view.tabs, document, settings, settings->path)) { return 1; }
    view.terminal.height = settings->terminal_height;
    view.tree.visible = editor_project_follow(&view.projects, &view.tree, settings->path);
    i32 result = 0;

    while (ui_window_poll_events()) {
        if (!editor_process_input(renderer, window, document, &view, settings)) {
            result = 1;

            break;
        }

        ui_window_set_cursor(window, editor_pointer_shape(window, &view, settings));

        if (!ui_window_is_visible(window)) {
            ui_sleep_ms(settings->minimized_pause_ms);

            continue;
        }

        if (!editor_draw(renderer, window, document, &view, settings) || !ui_window_wait_frame(window)) {
            result = 1;

            break;
        }
    }

    free(view.row_map);
    for (size_t i = 0; i < view.tabs.count; ++i) { editor_document_release(&view.tabs.items[i].saved_state); }
    editor_terminal_destroy(&view.terminal);
    editor_tree_destroy(&view.tree);

    return result;
}
