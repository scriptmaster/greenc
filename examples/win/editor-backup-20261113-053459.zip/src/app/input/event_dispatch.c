/*
 ** event_dispatch.c - 1 function.
 ** editor_process_input - Drain window events and dispatch editor commands.
 ** See also: editor_dispatch.h, main_internal.h.
 */
#include "main_internal.h"
#include "editor_hex.h"

bool editor_process_input(ui_renderer* renderer, ui_window* window, editor_document* document, editor_view* view,
                                  editor_settings* settings) {
    ui_input input;
    while (ui_window_next_input(window, &input)) {
        follow_active_file(view, document, settings);
        if (view->tree.naming && !input.close_requested) {
            if (!input.menu_command && !input.mouse) {
                editor_files_name_input(view, document, settings, input);

                continue;
            }

            if (input.mouse == UI_MOUSE_UP || input.mouse == UI_MOUSE_DRAG) { continue; }
            view->tree.naming = 0;
        }

        if (input.menu_command == MENU_SETTINGS) {
            view->themes.open = true;
            view->themes.expanded = true;
            view->tree.resizing = false;
            view->dragging = false;
            view->terminal.resizing = false;

            continue;
        }

        if (input.menu_command) {
            view->tree.focused = false;
            if (input.menu_command == MENU_SAVE || input.menu_command >= MENU_NEW) { view->themes.open = false; }
            view->terminal.focused = false;
            input = editor_menu_input(input.menu_command);
        }

        if (!input.mouse && !view->terminal.focused) { view->manual_scroll = false; }
        if (!input.close_requested) {
            view->caret_visible_since_ms = ui_time_ms();
        }

        if (input.close_requested || (input.control && input.key == UI_KEY_Q)) {
            if (view->themes.dirty && !ui_confirm("Modified theme", "Quit without saving the modified theme?")) {
                continue;
            }

            if (!editor_tabs_dirty(&view->tabs, document) || ui_confirm("Unsaved document", "Discard unsaved changes and quit?")) {
                ui_window_request_close(window);

                return true;
            }
        } else if (view->themes.open) {
            editor_themes_input(&view->themes, window, input, &settings->theme);
        } else if (input.key == UI_KEY_F6) {
            if (!cycle_frame_rate(window, settings)) { return false; }
        } else if (input.key == UI_KEY_F2 && view->tree.visible && view->tree.focused) {
            editor_files_rename(&view->tree);
        } else if (input.control && input.key == UI_KEY_GRAVE) {
            if (!editor_terminal_toggle(&view->terminal, settings)) { document->status = "Cannot start configured shell"; }
        } else if (input.control && input.key == UI_KEY_B) {
            view->tree.visible = !view->tree.visible;
        } else if (input.mouse) {
            if (!editor_mouse_input(renderer, window, document, view, settings, input)) { return false; }
        } else if (view->terminal.focused) {
            editor_terminal_key(&view->terminal, input);
        } else if (input.control && (input.key == UI_KEY_C || input.key == UI_KEY_X || input.key == UI_KEY_V)) {
            if (!document->binary) { editor_clipboard(document, window, input.key); }
        } else if (input.control && input.key == UI_KEY_S) {
            editor_tabs_save(&view->tabs, document, settings, window, input.shift);
        } else if (input.control && input.key == UI_KEY_N) {
            if (!editor_tabs_new(&view->tabs, document, settings)) { document->status = "File tab limit reached"; }
        } else if (input.control && input.key == UI_KEY_O) {
            char path[260] = {0};
            if (ui_choose_file(window, false, "txt", path)) { editor_tabs_open(&view->tabs, document, settings, path); }
        } else if (document->binary) {
            editor_hex_key(view, document, input);
        } else {
            editor_input(document, input);
        }
    }

    follow_active_file(view, document, settings);

    return true;
}
