/*
 ** document_scroll.c - 2 functions.
 ** document_scrollbar - Measure the scrollbar above the terminal.
 ** editor_scroll_input - Apply document wheel, track and thumb input.
 ** See also: editor_view.h, view_internal.h.
 */
#include "view_internal.h"

editor_scrollbar document_scrollbar(const editor_viewport* viewport, const editor_settings* settings) {
    return editor_scrollbar_layout((i32)viewport->width, (i32)settings->layout.text_top,
                                   (i32)(viewport->rows * viewport->cell_height), viewport->rows, viewport->visible_lines);
}

bool editor_scroll_input(editor_view* view, editor_document* document, ui_renderer* renderer,
                         ui_window* window, const editor_settings* settings, ui_input input) {
    editor_viewport viewport = {0};
    if (!editor_measure_viewport(renderer, window, document, settings, view, &viewport)) { return false; }

    editor_scrollbar bar = document_scrollbar(&viewport, settings);
    return editor_scroll_rows(view, bar, viewport.width, &view->first_line, input);
}
