/*
 ** theme_input.c - 1 function.
 ** editor_themes_input - Apply settings navigation, edits and theme file commands.
 ** See also: editor_themes.h, themes_internal.h.
 */
#include "themes_internal.h"

void editor_themes_input(editor_themes* page, ui_window* window, ui_input input, editor_theme* theme) {
    if (input.key == UI_KEY_ESCAPE) {
        page->open = false;
        page->controls.pressed = 0;

        return;
    }

    if (!input.mouse) { return; }

    u32 width, height;
    if (!ui_window_client_size(window, &width, &height)) { return; }
    i32 rows = visible_rows(height);
    scroll_fields(page, rows, 0);
    if (input.mouse == UI_MOUSE_WHEEL) {
        scroll_fields(page, rows, input.wheel_delta < 0 ? 3 : -3);
        page->controls.pressed = 0;

        return;
    }

    i32 target = 0;
    for (i32 id = CATEGORY; id < FIRST_FIELD + 2 * FIELD_COUNT; ++id) {
        if (control_visible(page, id, rows) && editor_contains(control_bounds(id, page->first), input.x, input.y)) {
            target = id;

            break;
        }
    }

    if (input.x >= 8 && input.x < 20 && input.y >= 38 && input.y < 66) { target = CATEGORY; }
    if (!editor_control_activate(&page->controls, input, target)) { return; }
    if (target >= FIRST_FIELD) {
        i32 field = (target - FIRST_FIELD) / 2;
        u32* value = theme_value(theme, field);
        if (fields[field].maximum) {
            i32 delta = (target - FIRST_FIELD) % 2 ? 1 : -1;
            i32 next = (i32)*value + delta;
            if (next < 0 || next > (i32)fields[field].maximum) { return; }

            *value = (u32)next;
        } else if (!ui_choose_color(window, value)) {
            return;
        }

        page->dirty = true;
        page->status = "Modified";

        return;
    }

    switch (target) {
        case CATEGORY:
            page->expanded = !page->expanded;
            page->changed = ui_time_ms();

            return;
        case THEMES: page->first = 0; return;
        case DONE: page->open = false; return;
        case PREVIOUS: scroll_fields(page, rows, -rows); return;
        case NEXT: scroll_fields(page, rows, rows); return;
    }

    bool save = target == SAVE;
    char path[260] = {0};
    if (save) { strcpy(path, page->path); }
    if (!ui_choose_file(window, save, "theme", path)) { return; }
    if (!save && page->dirty && !ui_confirm("Modified theme", "Replace the current unsaved colors?")) { return; }

    if (!(save ? editor_theme_save(theme, path) : editor_theme_load(theme, path))) {
        page->status = save ? "Save failed" : "Invalid theme file";
        return;
    }

    strcpy(page->path, path);
    page->dirty = false;
    page->status = save ? "Theme saved" : "Theme loaded";
}
