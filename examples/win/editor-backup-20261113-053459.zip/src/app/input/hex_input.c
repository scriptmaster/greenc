/*
 ** hex_input.c - 2 functions.
 ** editor_hex_mouse - Scroll the preview, activate full editing or select a byte.
 ** editor_hex_key - Navigate bytes and overwrite one hex digit at a time.
 ** See also: editor_hex.h, hex_view.c.
 */
#include "editor_hex.h"
#include <ctype.h>

void editor_hex_mouse(editor_view* view, editor_document* doc, ui_input input) {
    u32 cols = view->hex_columns, cw = view->hex_cell_width;
    if (!cols || !cw) { return; }

    bool on_button = !doc->full_hex && editor_contains(view->hex_action, input.x, input.y);
    if (editor_control_activate(&view->hex_button, input, on_button ? 1 : 0)) {
        doc->full_hex = true;
        doc->hex_first = 0;

        return;
    }

    if (input.mouse != UI_MOUSE_DOWN || input.y < view->hex_top || input.x < 8) { return; }
    u32 row = (input.y - view->hex_top) / view->hex_cell_height;
    u32 cell = (input.x - 8) / cw;
    u32 ascii = 11 + cols * 3;
    if (row >= view->hex_rows || cell < 10) { return; }

    if (cell < ascii && (cell - 10) % 3 == 2) { return; }
    u32 column = cell >= ascii ? cell - ascii : (cell - 10) / 3;
    size_t pos = (doc->hex_first + row) * cols + column;
    if (column < cols && pos < (doc->full_hex ? doc->length : 256)) {
        doc->cursor = pos;
        doc->low_nibble = cell < ascii && (cell - 10) % 3 == 1;
    }
}

void editor_hex_key(editor_view* view, editor_document* doc, ui_input input) {
    if (!doc->full_hex || !doc->length || !view->hex_columns) { return; }

    size_t pos = doc->cursor, last = doc->length - 1;
    u32 cols = view->hex_columns;
    switch (input.key) {
        case UI_KEY_LEFT: pos -= pos > 0; break;
        case UI_KEY_RIGHT: pos += pos < last; break;
        case UI_KEY_UP: pos = pos < cols ? 0 : pos - cols; break;
        case UI_KEY_DOWN: pos = last - pos < cols ? last : pos + cols; break;
        case UI_KEY_HOME: pos = input.control ? 0 : pos - pos % cols; break;
        case UI_KEY_END:
            pos = input.control || last - pos < cols - 1 - pos % cols ? last : pos + cols - 1 - pos % cols;
            break;
        default:
            if (input.control || input.character > 127 || !isxdigit((int)input.character)) { return; }
            u8 digit = input.character <= '9' ? (int)input.character - '0' : toupper((int)input.character) - 'A' + 10;
            u8 old = (u8)doc->text[pos];
            doc->text[pos] = doc->low_nibble ? (char)((old & 0xf0) | digit) : (char)((old & 15) | digit << 4);
            if (doc->low_nibble && pos < last) { ++pos; }

            doc->low_nibble = !doc->low_nibble;
            doc->dirty = true;
            break;
    }

    if (!input.character) { doc->low_nibble = false; }
    doc->cursor = pos;
    size_t row = pos / cols;
    if (row < doc->hex_first) { doc->hex_first = row; }
    if (view->hex_rows && row >= doc->hex_first + view->hex_rows) { doc->hex_first = row - view->hex_rows + 1; }
}
