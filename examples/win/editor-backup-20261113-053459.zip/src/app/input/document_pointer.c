/*
 ** document_pointer.c - 1 function.
 ** editor_mouse_select - Map document pointer gestures to selection and folding.
 ** See also: editor_view.h, view_internal.h.
 */
#include "view_internal.h"

void editor_mouse_select(editor_view* view, editor_document* document, ui_renderer* renderer,
                         ui_window* window, const editor_settings* settings, ui_input input) {
    editor_viewport viewport = {0};
    if (!editor_measure_viewport(renderer, window, document, settings, view, &viewport) ||
        !viewport.rows || !viewport.columns) { return; }

    i32 top = (i32)settings->layout.text_top;
    i32 bottom = top + (i32)(viewport.rows * viewport.cell_height);
    if (input.mouse == UI_MOUSE_DOWN) {
        view->dragging = input.y >= top && input.y < bottom;
        if (view->dragging && (!input.shift || !document->selecting)) {
            document->anchor = input.shift ? document->cursor : 0;
        }
    }

    if (!view->dragging) { return; }

    size_t row = view->first_line;
    if (input.y < top) {
        if (row) { --row; }
    } else {
        row += (size_t)(input.y - top) / viewport.cell_height;
    }

    if (row >= viewport.visible_lines) { row = viewport.visible_lines - 1; }
    size_t offset = viewport.map[row].offset;
    if (input.mouse == UI_MOUSE_DOWN && input.x >= (i32)viewport.text_left - 22 &&
        input.x < (i32)viewport.text_left && row < viewport.visible_lines) {
        size_t finish = editor_fold_end(document, offset);
        size_t next = editor_line_end(document, offset) + 1;
        if (finish > next) {
            if (!document->folded) {
                document->folded = calloc(document->capacity, sizeof(*document->folded));
                if (!document->folded) {
                    document->status = "Insufficient memory for folding";
                    view->dragging = false;

                    return;
                }
            }

            document->folded[offset] = !document->folded[offset];
            editor_document_changed(document);
            document->animated_fold = offset;
            document->fold_changed = ui_time_ms();
            if (document->folded[offset] && document->cursor >= next && document->cursor < finish) {
                document->cursor = offset;
                document->selecting = false;
            }
        }

        view->dragging = false;

        return;
    }

    size_t end = editor_line_end(document, offset);
    i32 x = input.x - (i32)viewport.text_left;
    size_t column = view->first_column;
    if (x >= 0) {
        column += ((size_t)x + viewport.cell_width / 2) / viewport.cell_width;
    } else if (column) {
        --column;
    }

    document->cursor = offset + (column < end - offset ? column : end - offset);
    if (input.mouse == UI_MOUSE_DOWN && !input.shift) {
        document->anchor = document->cursor;
    }

    document->selecting = true;
    if (input.mouse == UI_MOUSE_UP) { view->dragging = false; }
}
