/*
 ** document_rows.c - 2 functions.
 ** editor_draw_document - Paint document rows, line numbers, folds and selections.
 ** editor_draw_caret - Paint the caret during its visible blink phase.
 ** See also: view_internal.h.
 */
#include "view_internal.h"

void editor_draw_document(ui_renderer* renderer, const editor_document* document,
                                 const editor_view* view, const editor_viewport* viewport,
                                 const editor_settings* settings) {
    for (size_t row = 0; row < viewport->rows && view->first_line + row < viewport->visible_lines; ++row) {
        size_t index = view->first_line + row;
        size_t offset = viewport->map[index].offset;
        size_t end = viewport->map[index].end;
        size_t length = end - offset;
        size_t skip = view->first_column < length ? view->first_column : length;
        size_t count = length - skip;
        if (count > viewport->columns) {
            count = viewport->columns;
        }

        i32 y = (i32)settings->layout.text_top + (i32)(row * viewport->cell_height);
        char number[24];
        snprintf(number, sizeof(number), "%4zu", viewport->map[index].logical + 1);
        ui_renderer_text(renderer, (i32)settings->layout.margin, y, number,
                         view->first_line + row == viewport->cursor_line ? settings->theme.caret : settings->theme.muted);

        if (viewport->map[index].foldable) {
            editor_disclosure(renderer, viewport->text_left - 12, y + viewport->cell_height / 2,
                              !(document->folded && document->folded[offset]), document->animated_fold == offset ? document->fold_changed : 0,
                              settings->theme.muted, settings->theme.background);
        }

        size_t start, finish;
        editor_selection(document, &start, &finish);
        size_t visible = offset + view->first_column;
        size_t last = end + (end < document->length);
        if (start < visible) { start = visible; }
        if (finish > last) { finish = last; }
        if (finish > visible + viewport->columns) { finish = visible + viewport->columns; }

        if (finish > start) {
            i32 x = (i32)(viewport->text_left + (start - visible) * viewport->cell_width);
            ui_renderer_rect(renderer, x, y, (u32)(finish - start) * viewport->cell_width,
                             viewport->cell_height, settings->theme.selection);
        }

        for (size_t drawn = 0; drawn < count;) {
            char line[256];
            size_t chunk = count - drawn < sizeof(line) ? count - drawn : sizeof(line) - 1;
            memcpy(line, document->text + offset + skip + drawn, chunk);
            line[chunk] = 0;
            ui_renderer_text(renderer, viewport->text_left + drawn * viewport->cell_width, y, line, settings->theme.text);
            drawn += chunk;
        }
        if (end == document->length) {
            break;
        }
    }
}

void editor_draw_caret(ui_renderer* renderer, const editor_view* view,
                              const editor_viewport* viewport, const editor_settings* settings) {
    if (viewport->cursor_line < view->first_line || viewport->cursor_line - view->first_line >= viewport->rows) { return; }

    u64 idle_ms = ui_time_ms() - view->caret_visible_since_ms;
    if ((idle_ms / settings->layout.caret_blink_ms) % 2 != 0) {
        return;
    }

    i32 x = (i32)viewport->text_left +
            (i32)((viewport->cursor_column - view->first_column) * viewport->cell_width);
    i32 y = (i32)settings->layout.text_top +
            (i32)((viewport->cursor_line - view->first_line) * viewport->cell_height);
    ui_renderer_rect(renderer, x, y, settings->layout.caret_width,
                      viewport->cell_height, settings->theme.caret);
}
