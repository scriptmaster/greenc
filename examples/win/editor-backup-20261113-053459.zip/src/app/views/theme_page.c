/*
 ** theme_page.c - 2 functions.
 ** draw_control - Render a settings action with its pointer state.
 ** editor_themes_draw - Render the theme navigation, actions and editable fields.
 ** See also: editor_themes.h, themes_internal.h.
 */
#include "themes_internal.h"

static void draw_control(editor_themes* page, ui_renderer* renderer, const editor_theme* theme,
                         i32 id, const char* label, editor_control_kind kind) {
    editor_bounds b = control_bounds(id, page->first);
    bool hover = editor_contains(b, page->pointer_x, page->pointer_y);
    editor_control_draw(renderer, b, label, kind, theme, hover, page->controls.pressed == id, &page->transitions[id]);
}

void editor_themes_draw(editor_themes* page, ui_renderer* renderer, u32 width, u32 height, const editor_theme* theme) {
    (void)width;
    i32 rows = visible_rows(height);
    scroll_fields(page, rows, 0);
    ui_renderer_rect(renderer, 0, 0, SIDEBAR, height, theme->panel);
    ui_renderer_text(renderer, 12, 10, "Settings", theme->heading);
    editor_disclosure(renderer, 16, 52, page->expanded, page->changed, theme->text, theme->panel);
    draw_control(page, renderer, theme, CATEGORY, "Editor", EDITOR_LINK);
    if (page->expanded) { draw_control(page, renderer, theme, THEMES, "Themes", EDITOR_SECONDARY_LINK); }

    draw_control(page, renderer, theme, DONE, "Done", EDITOR_SECONDARY);
    ui_renderer_text(renderer, LEFT, 10, "Editor / Themes", theme->heading);
    ui_renderer_text(renderer, LEFT, 38, page->path[0] ? page->path : "Built-in theme", theme->muted);
    draw_control(page, renderer, theme, BROWSE, "Browse...", EDITOR_SECONDARY);
    draw_control(page, renderer, theme, SAVE, "Save As...", EDITOR_PRIMARY);
    if (page->status) { ui_renderer_text(renderer, LEFT + 224, 68, page->status, theme->muted); }
    if (page->first) { draw_control(page, renderer, theme, PREVIOUS, "Prev", EDITOR_LINK); }
    if (page->first + rows < FIELD_COUNT) { draw_control(page, renderer, theme, NEXT, "Next", EDITOR_LINK); }

    for (i32 i = page->first; i < page->first + rows; ++i) {
        i32 id = FIRST_FIELD + 2 * i;
        editor_bounds b = control_bounds(id, page->first);
        u32 value = *(const u32*)((const char*)theme + fields[i].offset);
        char label[64];
        if (fields[i].maximum) {
            snprintf(label, sizeof(label), "%s %u%s", fields[i].name, value, fields[i].maximum == 100 ? "%" : "px");
            ui_renderer_text(renderer, LEFT, b.y + 4, label, theme->text);
            draw_control(page, renderer, theme, id, "-", EDITOR_SECONDARY);
            draw_control(page, renderer, theme, id + 1, "+", EDITOR_SECONDARY);
        } else {
            snprintf(label, sizeof(label), "%s  #%06X", fields[i].name, value);
            draw_control(page, renderer, theme, id, label, EDITOR_SECONDARY);
            ui_renderer_rect(renderer, b.x + b.width - 24, b.y + 6, 14, 14, value);
        }
    }
}
