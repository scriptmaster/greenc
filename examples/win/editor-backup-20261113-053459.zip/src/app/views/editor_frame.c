/*
 ** editor_frame.c - 1 function.
 ** editor_draw - Compose and present a complete editor frame.
 ** See also: editor_view.h, view_internal.h.
 */
#include "view_internal.h"
#include "editor_hex.h"

bool editor_draw(ui_renderer* renderer, ui_window* window, editor_document* document,
                 editor_view* view, const editor_settings* settings) {
    if (!ui_renderer_begin(renderer, settings->theme.background)) {
        return false;
    }

    editor_viewport viewport = {0};
    if (view->themes.open) {
        if (!ui_window_client_size(window, &viewport.width, &viewport.height)) { return false; }

        view->themes.pointer_x = view->themes.pointer_y = -1;
        ui_window_pointer(window, &view->themes.pointer_x, &view->themes.pointer_y);
        editor_themes_draw(&view->themes, renderer, viewport.width, viewport.height, &settings->theme);

        return ui_renderer_present(renderer);
    }

    if (document->binary) {
        if (!ui_window_client_size(window, &viewport.width, &viewport.height)) { return false; }
        viewport.width -= editor_tree_width(&view->tree, viewport.width);
        u32 bottom = viewport.height > settings->layout.footer_height ? viewport.height - settings->layout.footer_height : 0;
        bottom -= editor_terminal_size(&view->terminal, bottom);
        editor_hex_draw(view, document, renderer, window, viewport.width, bottom, settings);
        viewport.cursor_line = document->cursor / view->hex_columns;
        viewport.cursor_column = document->cursor % view->hex_columns;
    } else if (!editor_measure_viewport(renderer, window, document, settings, view, &viewport)) {
        return false;
    }

    editor_tabs_draw(&view->tabs, document, renderer, viewport.width, settings);
    if (viewport.rows && viewport.columns) {
        editor_scrollbar bar = document_scrollbar(&viewport, settings);
        if (view->first_line > bar.maximum) { view->first_line = bar.maximum; }
        editor_scroll_to_cursor(view, &viewport);
        editor_draw_document(renderer, document, view, &viewport, settings);
        editor_scrollbar_draw(bar, renderer, view->first_line, settings->theme.panel, settings->theme.muted);

        if (!view->terminal.focused) { editor_draw_caret(renderer, view, &viewport, settings); }
    }

    if (!ui_window_client_size(window, &viewport.width, &viewport.height)) { return false; }
    u32 bottom = viewport.height > settings->layout.footer_height ? viewport.height - settings->layout.footer_height : 0;
    editor_terminal_draw(&view->terminal, renderer, viewport.width, bottom, settings);
    editor_tree_draw(&view->tree, renderer, viewport.width, bottom - editor_terminal_size(&view->terminal, bottom), settings);
    editor_project_draw(&view->projects, &view->tree, renderer, viewport.width, settings);
    if (viewport.height >= settings->layout.footer_height) {
        editor_status_draw(&view->status_bar, renderer, window, document, settings, viewport.width, viewport.height,
                           viewport.map ? (size_t)viewport.map[viewport.cursor_line].logical + 1 : viewport.cursor_line + 1, viewport.cursor_column + 1);
    } else {
        view->status_bar.bottom = view->status_bar.top;
    }

    return ui_renderer_present(renderer);
}
