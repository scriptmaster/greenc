/*
 ** editor_start.c - 1 function.
 ** editor_start - Initialize the document, window and renderer and run the editor.
 ** See also: editor_start.h, main_internal.h.
 */
#include "main_internal.h"

int editor_start(int argc, char** argv) {
    editor_settings settings = editor_settings_init();
    if (!editor_settings_parse(&settings, argc, argv)) {
        return ui_report_error("Options: --cpu --fps=0..1000 --windowed --fullscreen --borderless [file]");
    }

    editor_document document = {.status = "Ready"};
    if (!editor_load(&document, settings.path)) {
        return ui_report_error(document.open_error);
    }

    ui_window* window = ui_window_create(&settings.window);
    if (!window) {
        editor_document_release(&document);
        return ui_report_error("Cannot create editor window.");
    }

    if (!ui_window_set_menu(window, editor_menu, sizeof(editor_menu) / sizeof(editor_menu[0]))) {
        editor_document_release(&document);
        ui_window_destroy(window);

        return ui_report_error("Cannot create editor menu.");
    }

    ui_renderer* renderer = ui_renderer_create(window, &settings.renderer);
    if (!renderer) {
        editor_document_release(&document);
        ui_window_destroy(window);

        return ui_report_error("Cannot create editor renderer.");
    }

    i32 result = editor_run(window, renderer, &document, &settings);

    editor_document_release(&document);
    ui_renderer_destroy(renderer);
    ui_window_destroy(window);

    return result ? ui_report_error("Editor rendering or frame pacing failed.") : 0;
}
