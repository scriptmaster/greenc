/*
 ** tests.c - 4 functions.
 ** exercise_console - Verify command execution in a detached shell.
 ** test_console - Start and join the detached console test process.
 ** test_tab_strip - Check scrolling, selection and close targets.
 ** main - Run document, project, console and editor regression checks.
 ** See also: editor_document.h, editor_projects.h.
 */
#include "editor_tabs.h"
#include "editor_projects.h"
#include "sys/fs/entries.h"
#include "editor_scrollbar.h"
#include "row_index.h"
#include "editor_hex.h"
#include "file_size.h"
#include "editor_status.h"
#include "editor_themes.h"
#include "editor_tree.h"
#include "editor_document.h"
#include "sys/shell.h"
#include "sys/console.h"
#include "editor_input.h"
#include "editor_settings.h"
#include <stdio.h>
#include <string.h>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "sys/fs/write_atomic.h"
#include <assert.h>

static int exercise_console(const char* profile) {
    sys_console* console = sys_console_start(profile);
    sys_console_view view;
    bool ready = false;
    for (unsigned i = 0; console && i < 100 && !ready; ++i) {
        ready = sys_console_viewport(console, 80, 16, &view);
        if (!ready) { Sleep(20); }
    }

    if (ready && !strcmp(profile, "powershell.exe")) {
        bool prompt = false;
        for (unsigned i = 0; i < 500 && !prompt; ++i) {
            Sleep(20);
            char line[81];
            if (sys_console_viewport(console, 80, 16, &view) &&
                sys_console_row(console, view.left, view.top + view.cursor_y, line, 80)) {
                if (strstr(line, "default is") && strchr(line, 'D')) {
                    sys_console_input(console, SYS_CHAR, 'D', false, false);
                    sys_console_input(console, SYS_CHAR, '\r', false, false);
                    Sleep(200);
                }

                prompt = strstr(line, "PS ") && strchr(line, '>');
            }
        }

        ready = prompt;
    }

    const char* command = "echo terminal-ready\r";
    for (const char* c = command; ready && *c; ++c) {
        ready = sys_console_input(console, SYS_CHAR, *c, false, false);
    }

    bool matched = false;
    for (unsigned i = 0; ready && !matched && i < 250; ++i) {
        Sleep(20);
        if (!sys_console_viewport(console, 80, 16, &view)) { break; }
        for (int y = 0; y < 16; ++y) {
            char line[81];
            if (sys_console_row(console, view.left, view.top + y, line, 80) && !strcmp(line, "terminal-ready")) {
                matched = true;

                break;
            }
        }
    }

    sys_console_destroy(console);

    return matched ? 0 : 1;
}

static void test_console(const char* profile) {
    char executable[MAX_PATH], command[128];
    snprintf(command, sizeof(command), "tests.exe --console %s", profile);
    assert(GetModuleFileNameA(NULL, executable, sizeof(executable)));
    STARTUPINFOA startup = {.cb = sizeof(startup)};
    PROCESS_INFORMATION process;
    assert(CreateProcessA(executable, command, NULL, NULL, FALSE, DETACHED_PROCESS, NULL, NULL, &startup, &process));
    assert(WaitForSingleObject(process.hProcess, 30000) == WAIT_OBJECT_0);
    DWORD result;
    assert(GetExitCodeProcess(process.hProcess, &result) && result == 0);
    CloseHandle(process.hThread);
    CloseHandle(process.hProcess);
}

static void test_tab_strip(void) {
    for (u32 picker = 0; picker <= 1; ++picker) {
        editor_tab_scroll scroll = {0};
        editor_tab_strip strip = editor_strip_layout(&scroll, 1, 0, 600, 8, picker);
        size_t index = 99;
        assert(strip.plus_x == 2 * strip.button + strip.tab);
        assert(editor_strip_click(&strip, &scroll, strip.plus_x, &index) == TAB_ADD);
        assert(editor_strip_click(&strip, &scroll, strip.plus_x + strip.button, &index) ==
               (picker ? TAB_PICKER : TAB_NONE));

        strip = editor_strip_layout(&scroll, 6, 0, 360, 8, picker);
        assert(strip.visible == 2);
        editor_strip_click(&strip, &scroll, strip.button, &index);
        strip = editor_strip_layout(&scroll, 6, 0, 360, 8, picker);
        assert(strip.first == 1);
        assert(editor_strip_click(&strip, &scroll, 2 * strip.button, &index) == TAB_SELECT && index == 1);

        assert(editor_strip_click(&strip, &scroll, 2 * strip.button + strip.tab - 1, &index) == TAB_CLOSE);
        assert(index == 1);

        scroll.reveal_active = true;
        strip = editor_strip_layout(&scroll, 7, 6, 360, 8, picker);
        assert(strip.first + strip.visible == 7);
        editor_strip_click(&strip, &scroll, 0, &index);
        assert(scroll.first == strip.first - 1);

        strip = editor_strip_layout(&scroll, 7, 6, 0, 8, picker);
        assert(!strip.visible && editor_strip_click(&strip, &scroll, 0, &index) == TAB_NONE);
    }
}

int main(int argc, char** argv) {
    if (argc == 4 && !strcmp(argv[1], "--check-link")) {
        editor_document linked = {0};
        u64 target, link;
        assert(sys_file_size(argv[3], &target) && target > 0);
        assert(sys_file_size(argv[2], &link) && link == target);
        assert(editor_load_existing(&linked, argv[2]));
        assert(linked.disk_bytes == target && linked.modified[0]);
        printf("Symlink and target both report %llu bytes.\\n", (unsigned long long)target);
        editor_document_release(&linked);

        return 0;
    }
    if (argc == 3 && !strcmp(argv[1], "--open-large")) {
        editor_document large = {0};
        assert(editor_load(&large, argv[2]) && large.length > 4095);
        assert(large.text[large.length] == 0);
        editor_document_release(&large);

        return 0;
    }

    test_tab_strip();
    assert(editor_marquee_offset(0, 4000) == 0);
    assert(editor_marquee_offset(50, 1200) == 0);
    assert(editor_marquee_offset(50, 1520) == 10);
    assert(editor_marquee_offset(50, 2800) == 50);
    assert(editor_marquee_offset(50, 5600) == 0);
    editor_status_bar footer = {.fps_left = 540, .fps_right = 590, .top = 400, .bottom = 428};
    assert(editor_status_hit(&footer, 540, 400) && !editor_status_hit(&footer, 590, 412));
    editor_scrollbar bar = editor_scrollbar_layout(600, 40, 240, 15, 90);
    assert(bar.maximum == 75 && editor_scroll_position(bar, editor_thumb_top(bar, 75)) == 75);
    assert(editor_scroll_position(bar, -100) == 0 && editor_scroll_position(bar, 999) == 75);
    assert(!editor_scrollbar_layout(600, 40, 240, 15, 15).maximum);

    editor_control_input control = {0};
    assert(!editor_control_activate(&control, (ui_input){.mouse = UI_MOUSE_DOWN}, 1));
    assert(!editor_control_activate(&control, (ui_input){.mouse = UI_MOUSE_UP}, 2));
    assert(!editor_control_activate(&control, (ui_input){.mouse = UI_MOUSE_DOWN}, 2));
    assert(editor_control_activate(&control, (ui_input){.mouse = UI_MOUSE_UP}, 2));
    if (argc >= 2 && !strcmp(argv[1], "--console")) { return exercise_console(argc == 3 ? argv[2] : "cmd.exe"); }
    test_console(argc == 3 && !strcmp(argv[1], "--profile") ? argv[2] : "cmd.exe");

    editor_document folded = {.text = "outer\n  inner\n    body\nnext"};
    folded.length = strlen(folded.text);
    assert(editor_fold_end(&folded, 0) == 23);
    assert(editor_fold_end(&folded, 6) == 23);
    assert(editor_fold_end(&folded, 23) == folded.length + 1);

    editor_document navigation = {.text = "first\nlast", .length = 10};
    editor_input(&navigation, (ui_input){.key = UI_KEY_DOWN, .shift = true});
    editor_input(&navigation, (ui_input){.key = UI_KEY_DOWN, .shift = true});
    assert(navigation.anchor == 0 && navigation.cursor == 10);
    editor_input(&navigation, (ui_input){.key = UI_KEY_HOME, .control = true});
    assert(navigation.cursor == 0);
    editor_input(&navigation, (ui_input){.key = UI_KEY_END, .control = true});
    assert(navigation.cursor == 10);

    sys_shell* shell = sys_shell_create("cmd.exe");
    assert(shell);
    const char command[] = "@echo result=%COMSPEC%\r\n";
    assert(sys_shell_send(shell, command, sizeof(command) - 1));
    char capture[2048] = {0};
    size_t received = 0;
    for (size_t attempt = 0; attempt < 200 && !strstr(capture, "result=C:"); ++attempt) {
        received += sys_shell_read(shell, capture + received, sizeof(capture) - 1 - received);
        Sleep(10);
    }

    sys_shell_destroy(shell);
    assert(strstr(capture, "result=C:"));

    editor_document document = {.status = "Ready"};
    editor_input(&document, (ui_input){.character = 'a'});
    editor_input(&document, (ui_input){.character = '\n'});
    editor_input(&document, (ui_input){.character = 'b'});
    assert(strcmp(document.text, "a\nb") == 0 && document.cursor == 3 && document.dirty);
    editor_input(&document, (ui_input){.key = UI_KEY_UP});
    assert(document.cursor == 1);
    editor_input(&document, (ui_input){.key = UI_KEY_HOME});
    editor_input(&document, (ui_input){.character = 'x'});
    assert(strcmp(document.text, "xa\nb") == 0);
    editor_input(&document, (ui_input){.key = UI_KEY_DOWN});
    assert(document.cursor == 4);
    editor_input(&document, (ui_input){.character = '\b'});
    assert(strcmp(document.text, "xa\n") == 0);
    editor_input(&document, (ui_input){.character = '\b'});
    assert(strcmp(document.text, "xa") == 0);
    editor_input(&document, (ui_input){.key = UI_KEY_HOME});
    editor_input(&document, (ui_input){.key = UI_KEY_DELETE});
    assert(strcmp(document.text, "a") == 0 && document.length == 1);
    editor_input(&document, (ui_input){.character = '\t'});
    assert(strcmp(document.text, "    a") == 0);
    editor_input(&document, (ui_input){.character = 19, .control = true});
    assert(document.length == 5); /* Ctrl+S must not insert its control character. */
    editor_input(&document, (ui_input){.key = UI_KEY_A, .control = true});
    editor_input(&document, (ui_input){.character = 'z'});
    assert(strcmp(document.text, "z") == 0);
    editor_input(&document, (ui_input){.key = UI_KEY_LEFT, .shift = true});
    assert(document.anchor == 1 && document.cursor == 0);
    editor_input(&document, (ui_input){.key = UI_KEY_DELETE});
    assert(document.length == 0);

    assert(editor_document_reserve(&document, 4096));
    memset(document.text, 'a', 4095);
    document.length = 4095;
    document.cursor = document.length;
    document.text[document.length] = '\0';
    editor_input(&document, (ui_input){.character = 'b'});
    assert(document.length == 4096 && document.text[4095] == 'b');
    editor_settings settings = editor_settings_init();
    assert(settings.window.mode == UI_WINDOW_MAXIMIZED && settings.window.target_fps == 60);
    char* arguments[] = {"editor", "--cpu", "--fps=144", "--borderless", "draft.txt"};
    assert(editor_settings_parse(&settings, 5, arguments));
    assert(settings.renderer.preference == UI_RENDERER_CPU && settings.window.target_fps == 144);
    assert(!settings.window.title_bar && !settings.window.minimize_button);
    assert(strcmp(settings.path, "draft.txt") == 0);
    assert(editor_next_frame_rate(&settings, 144) == 240);
    char* invalid[] = {"editor", "--fps=1001"};
    assert(!editor_settings_parse(&settings, 2, invalid));

    char directory[MAX_PATH], path[MAX_PATH];
    assert(GetTempPathA(MAX_PATH, directory));
    assert(GetTempFileNameA(directory, "gce", 0, path));
    const char* source = "first\r\nsecond\rthird\tend";
    char* boundary = malloc(65540);
    assert(boundary);
    memset(boundary, 'x', 65535);
    memcpy(boundary + 65535, "\r\n\tz", 4);
    assert(sys_file_write_atomic(path, boundary, 65539));
    free(boundary);
    assert(editor_load_existing(&document, path));
    assert(document.length == 65541 && !strcmp(document.text + 65535, "\n    z"));
    if (sizeof(size_t) > 4) {
        size_t large_offset = (size_t)UINT32_MAX + 100u;
        editor_line_entry entries[] = {{.offset = 0}, {.offset = large_offset}, {.offset = large_offset + 42}};
        editor_view index = {.row_map = entries, .mapped_rows = 3};
        assert(editor_cursor_row(&index, large_offset + 41) == 1 && editor_cursor_row(&index, large_offset + 42) == 2);
    }

    assert(sys_file_write_atomic(path, source, strlen(source)));
    assert(editor_load(&document, path));
    assert(strcmp(document.text, "first\nsecond\nthird    end") == 0);
    assert(!document.dirty && document.cursor == 0);

    editor_insert_character(&document, 'x');
    editor_save(&document, path);
    assert(!document.dirty && strcmp(document.status, "Saved") == 0);
    editor_document reloaded = {0};
    assert(editor_load(&reloaded, path) && strcmp(document.text, reloaded.text) == 0);

    assert(sys_file_write_atomic(path, "\x80", 1));
    assert(editor_load(&document, path) && document.binary && document.full_hex && document.disk_bytes == 1);
    assert(document.modified[0] && (u8)document.text[0] == 0x80);
    char binary[257];
    memset(binary, 0x80, sizeof(binary));
    memcpy(binary, "A\r\n\t", 4);
    assert(sys_file_write_atomic(path, binary, 256));
    assert(editor_load(&document, path) && document.full_hex && !memcmp(document.text, binary, 256));
    assert(sys_file_write_atomic(path, binary, sizeof(binary)));
    assert(editor_load(&document, path) && document.binary && !document.full_hex && document.disk_bytes == 257);
    assert(!memcmp(document.text, binary, sizeof(binary)));
    editor_view hex_view = {.hex_columns = 16, .hex_rows = 8};
    char formatted[16];
    editor_format_size(formatted, 999);
    assert(!strcmp(formatted, "999 B"));
    editor_format_size(formatted, 1000);
    assert(!strcmp(formatted, "1.0 KB"));
    editor_format_size(formatted, 1250);
    assert(!strcmp(formatted, "1.3 KB"));
    editor_format_size(formatted, 1500000);
    assert(!strcmp(formatted, "1.5 MB"));
    editor_format_size(formatted, 2500000000ULL);
    assert(!strcmp(formatted, "2.5 GB"));

    hex_view.hex_cell_width = 8;
    hex_view.hex_cell_height = 16;
    hex_view.hex_top = 48;
    editor_hex_mouse(&hex_view, &document, (ui_input){.mouse = UI_MOUSE_DOWN, .x = 8 + (11 + 48 + 3) * 8, .y = 65});
    assert(document.cursor == 19);
    editor_hex_mouse(&hex_view, &document, (ui_input){.mouse = UI_MOUSE_DOWN, .x = 8 + (10 + 3 * 7) * 8, .y = 65});
    assert(document.cursor == 23);
    editor_scrollbar hex_bar = editor_scrollbar_layout(640, 48, 128, 8, 17);
    assert(editor_scroll_rows(&hex_view, hex_bar, 640, &document.hex_first,
                              (ui_input){.mouse = UI_MOUSE_DOWN, .x = hex_bar.x, .y = 49}));
    assert(editor_scroll_rows(&hex_view, hex_bar, 640, &document.hex_first,
                              (ui_input){.mouse = UI_MOUSE_UP, .x = 650, .y = 250}));
    assert(document.hex_first == 9 && !hex_view.scrolling);

    document.full_hex = true;
    editor_hex_key(&hex_view, &document, (ui_input){.key = UI_KEY_END, .control = true});
    editor_hex_key(&hex_view, &document, (ui_input){.character = 'F'});
    editor_hex_key(&hex_view, &document, (ui_input){.character = '1'});
    assert(document.cursor == 256 && (u8)document.text[256] == 0xf1 && document.dirty);
    editor_save(&document, path);
    assert(editor_load(&document, path) && (u8)document.text[256] == 0xf1);
    assert(sys_file_write_atomic(path, "test", 4) && editor_load(&document, path));
    editor_tabs tabs = {0};
    assert(editor_tabs_open(&tabs, &document, &settings, path));
    editor_insert_character(&document, 'T');
    size_t cursor = document.cursor;
    char second[MAX_PATH];
    assert(GetTempFileNameA(directory, "tab", 0, second));
    assert(editor_tabs_open(&tabs, &document, &settings, second));
    assert(!document.dirty && editor_tabs_dirty(&tabs, &document));
    editor_tabs_step(&tabs, &document, &settings, -1);
    assert(document.dirty && document.cursor == cursor && document.text[cursor - 1] == 'T');
    assert(editor_tabs_open(&tabs, &document, &settings, second) && tabs.count == 2);
    editor_theme parsed = {0};
    const char* legacy = "background=#101010\npanel=#202020\ntext=#ffffff\nheading=#ffffff\n"
                         "muted=#aaaaaa\ncaret=#ffeeee\nselection=#334455\n";
    assert(sys_file_write_atomic(second, legacy, strlen(legacy)));
    assert(editor_theme_load(&parsed, second) && parsed.background == 0x101010);
    assert(parsed.button.radius == settings.theme.button.radius);
    settings.theme.button.radius = 9;
    settings.theme.link.press_percent = 42;
    assert(editor_theme_save(&settings.theme, second));
    assert(editor_theme_load(&parsed, second));
    assert(!memcmp(&parsed, &settings.theme, sizeof(parsed)));
    assert(sys_file_write_atomic(second, "panel=#ffffff", 13));
    assert(!editor_theme_load(&parsed, second));
    assert(!memcmp(&parsed, &settings.theme, sizeof(parsed)));

    editor_tree tree = {.visible = true};
    assert(editor_tree_resize(&tree, 900, 500, (ui_input){.mouse = UI_MOUSE_DOWN, .x = 620, .y = 40}));
    assert(editor_tree_resize(&tree, 900, 500, (ui_input){.mouse = UI_MOUSE_UP, .x = 450, .y = 40}));
    assert(!tree.resizing && editor_tree_width(&tree, 900) == 450);
    assert(editor_tree_width(&tree, 200) == 40);

    assert(editor_tabs_new(&tabs, &document, &settings));
    assert(!document.length && tabs.items[tabs.active].untitled);
    assert(editor_tabs_dirty(&tabs, &document));

    editor_tabs_close(&tabs, tabs.active, &document, &settings);
    assert(tabs.count == 2 && !strcmp(settings.path, second));
    editor_tabs_close(&tabs, tabs.active, &document, &settings);
    assert(tabs.count == 1 && document.dirty && document.cursor == cursor);
    document.dirty = false;
    editor_tabs_close(&tabs, 0, &document, &settings);
    assert(tabs.count == 1 && tabs.items[0].untitled && !document.length);

    editor_document_release(&reloaded);
    editor_document_release(&document);
    assert(DeleteFileA(second));
    assert(DeleteFileA(path));
    assert(sys_folder_create(path));
    char child[SYS_PATH_CAPACITY], copy[SYS_PATH_CAPACITY], moved[SYS_PATH_CAPACITY];
    assert(!sys_child_path(path, "..", child) && !sys_child_path(path, "a/b", child));
    assert(!sys_child_path(path, "NUL.txt", child));
    assert(sys_child_path(path, "note.txt", child) && sys_child_path(path, "copy.txt", copy));
    assert(sys_child_path(path, "renamed.txt", moved));
    assert(sys_file_create_empty(child) && !sys_file_create_empty(child));
    assert(sys_file_write_atomic(child, "abc", 3));
    assert(sys_file_copy_new(child, copy) && !sys_file_copy_new(child, copy));
    assert(!sys_entry_rename(child, copy) && sys_entry_rename(copy, moved));

    editor_tree explorer = {0};
    editor_tree_init(&explorer, child);
    assert(explorer.visible && explorer.count == 2 && !strcmp(explorer.selected, child));
    assert(editor_tree_root(&explorer, directory));
    assert(editor_tree_follow(&explorer, child) && !strcmp(explorer.root, directory));
    assert(editor_tree_follow(&explorer, moved) && !strcmp(explorer.selected, moved) && explorer.count == 2);
    editor_tree_destroy(&explorer);

    editor_projects projects = {0};
    editor_tree project_tree = {0};
    assert(editor_project_follow(&projects, &project_tree, moved));
    assert(projects.count == 1 && projects.active == 0);
    char nested[SYS_PATH_CAPACITY], nested_file[SYS_PATH_CAPACITY];
    assert(sys_child_path(path, "nested", nested) && sys_folder_create(nested));
    assert(sys_child_path(nested, "nested.c", nested_file));
    assert(editor_project_follow(&projects, &project_tree, nested_file));
    assert(projects.count == 1 && !_stricmp(projects.roots[0], path));
    assert(editor_project_open(&projects, &project_tree, directory) && projects.count == 2);
    assert(editor_project_open(&projects, &project_tree, path) && projects.active == 0);
    assert(RemoveDirectoryA(nested));
    editor_tree_destroy(&project_tree);
    u64 bytes = 0;
    assert(sys_file_size(moved, &bytes) && bytes == 3);
    assert(sys_file_delete(child) && sys_file_delete(moved) && RemoveDirectoryA(path));

    puts("PASS: editor insertion, line navigation, deletion, tabs, control input, capacity, options, load normalization and save.");

    return 0;
}
