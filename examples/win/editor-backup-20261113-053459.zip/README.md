# Windows editor

From this directory, run `make` with the MinGW GCC toolchain and launch `editor.exe [file]`. Run `make test` for the editor checks. The entry point is in `src/main.c`. Application contracts are in `src/app/*.h` and the implementation directories group startup, entities, views, input, workflows and utilities.

The footer shows the document path on the left. Long paths scroll back and forth within the available space. Click the FPS value at the right edge or press F6 to cycle the configured frame rates.

## Files panel

Ctrl+B toggles the panel. The first named document establishes a project root. Opening a descendant keeps that root. Opening an external file activates its existing project or adds its containing folder as another Files tab. Use the strip arrows to scroll folders, **+** to browse for a folder, and **�** to close its Files tab. Untitled documents keep the current project.

Right-click a folder to create a file or directory inside it. On a file, **New File Here** uses its containing folder. **New File in Panel Root** is also available from nested folders. Type a single name in the panel header. Enter applies it and Escape cancels. New files open in a tab immediately.

Right-click a file to duplicate, duplicate under a chosen name, rename, inspect its size, open Windows Properties or launch its containing folder in Explorer. F2 renames the selected file while the panel has focus. Duplicates copy the saved bytes on disk. Rename preserves edits in open tabs. Delete asks for confirmation and permanently removes the selected file. Save or close a modified tab before deleting its file. File creation, duplication and rename preserve existing destination files.

The editor currently accepts ASCII text documents that fit in available process memory, including normalized text and the row index, and the Windows file dialogs and paths use the native ANSI path limit.

## Large-file performance

The editor reads 64 KiB blocks into a growing flat text buffer. A flat index records visible line boundaries. Scrolling paints the viewport, and caret jumps use binary search on that index. The working set includes text, index entries and allocation headroom. Fold flags are allocated on first use. Opening, saving, editing a flat buffer and rebuilding its index can still take time proportional to file size.

To measure your machine, build `make bin/scroll_benchmark.exe` and run `bin/scroll_benchmark.exe path/to/file.txt` with a supported document containing more than 1,000 lines. The CPU benchmark reports file loading, first index and frame, 200 wheel-and-paint frames, and 10,000 cursor lookups without frame-rate pacing.

## File details and hex editing

File tabs and the footer use bytes below 1,000 and decimal KB, MB and GB with one decimal place above that. Symbolic links show their target�s size. The footer gives the active file�s saved file size and local modification timestamp. Unsaved new documents show their buffer size. Memory is the process working set in decimal MB, sampled every 500 ms. The FPS control identifies the renderer; CPU mode also shows process CPU as a percentage of total logical processor capacity.

Files containing non-ASCII or binary bytes open with hexadecimal and printable-character columns. Non-printable bytes appear as middle dots. Up to 256 bytes open directly for editing. Larger files preview the first 256 bytes; choose **Open Hex Editor** for the full file. Scroll with the wheel or drag the scrollbar. Click either byte column to highlight the same byte on both sides, or use arrows and Ctrl+Home/End. Type two hex digits to overwrite a byte and use Ctrl+S to save.
